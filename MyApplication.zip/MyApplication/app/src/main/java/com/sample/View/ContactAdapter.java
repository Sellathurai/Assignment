package com.sample.View;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.sample.Modal.DatabaseHandler;
import com.sample.assigment.Contact;
import com.sample.assigment.MainActivity;
import com.sample.assigment.R;

import java.util.List;

/**
 * Created by R.SELLATHURAI on 6/1/2017.
 */

public class ContactAdapter extends BaseAdapter {
    Context mcontext;
   List<Contact> mContactsList;
    DatabaseHandler mdb;
    public ContactAdapter(Context context, List<Contact> contactsList) {
        super();
        this.mContactsList=contactsList;
        this.mcontext = context;
        mdb = new DatabaseHandler(context);
    }
    @Override
    public int getCount() {
        return mContactsList.size();
    }

    @Override
    public Object getItem(int position) {
        return mContactsList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder=null;
        Contact contact=mContactsList.get(position);
        if (convertView == null) {
            holder = new ViewHolder();
            LayoutInflater mInflater = (LayoutInflater) mcontext
                    .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            convertView = mInflater.inflate(R.layout.contact_items, null);
            holder.name=(TextView) convertView.findViewById(R.id.name);
            holder.phone=(TextView) convertView.findViewById(R.id.phone);
            holder.id=(TextView) convertView.findViewById(R.id.id);
            holder.edit=(Button) convertView.findViewById(R.id.edit);
            holder.delete=(Button) convertView.findViewById(R.id.delete);


            convertView.setTag(holder);
        }
        else
        {
            holder =(ViewHolder)convertView.getTag();
        }

        holder.name.setText(contact.getName());
        holder.phone.setText(contact.getPhoneNumber());
        holder.id.setText(""+contact.getID());
        holder.delete.setTag(contact.getID());
        holder.edit.setTag(contact.getID());

    holder.delete.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {

        int id = (int) view.getTag();
        openAlertDialog(id);

    }
});
        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int id=(int)view.getTag();
                for (int i = 0; i < mContactsList.size(); i++) {
                    if (mContactsList.get(i).getID() == id) {
                        MainActivity activity = (MainActivity) mcontext;
                        activity.editContact(mContactsList.get(i).getName(),mContactsList.get(i).getPhoneNumber(),mContactsList.get(i).getID());
                    }
                }
              }
        });

        return convertView;
    }
    /**
     * This alert dialog used for confirmation of delete action
     */
    public void openAlertDialog(final int id){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(mcontext);
        alertDialogBuilder.setMessage("Are you sure,You wanted to make decision");
                alertDialogBuilder.setPositiveButton("Delete",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {

                                for (int i = 0; i < mContactsList.size(); i++) {
                                    if (mContactsList.get(i).getID() == id) {
                                        Contact contact = new Contact();
                                        contact.setName(mContactsList.get(i).getName());
                                        contact.setPhoneNumber(mContactsList.get(i).getPhoneNumber());
                                        contact.setID(mContactsList.get(i).getID());
                                        mdb.deleteContact(contact);

                                        MainActivity activity = (MainActivity) mcontext;
                                        activity.loadAdapter();
                                        notifyDataSetChanged();
                                        Toast.makeText(mcontext, "Data has been deleted successfully",Toast.LENGTH_LONG).show();
                                    }
                                }
                            }
                        });

        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
// VIEW OBJECT
    private class ViewHolder {
        public TextView name,phone,id;
        public Button edit,delete;

    }
}
