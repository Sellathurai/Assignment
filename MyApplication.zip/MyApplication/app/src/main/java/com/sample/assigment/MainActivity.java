package com.sample.assigment;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.sample.Modal.DatabaseHandler;
import com.sample.View.ContactAdapter;

import java.util.List;
/**
 * Created by R.SELLATHURAI on 6/1/2017.
 */
public class MainActivity extends Activity {

    ListView listView;
    EditText name,phone;
    Button addContact,saveContact;
    ContactAdapter contactAdapter;
    int primaryId;
    LinearLayout linearLayout;
    DatabaseHandler db = new DatabaseHandler(MainActivity.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView=(ListView)findViewById(R.id.list_of_items);
        addContact=(Button)findViewById(R.id.addContact);
        saveContact=(Button)findViewById(R.id.save);
        name=(EditText)findViewById(R.id.personName);
        phone=(EditText)findViewById(R.id.phoneNo);
        linearLayout=(LinearLayout)findViewById(R.id.contactLayout);

        linearLayout.setVisibility(View.GONE);
        saveContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (name.getText().toString().trim().length() == 0 && phone.getText().toString().trim().length() == 0) {
                    Toast.makeText(MainActivity.this, "Please enter both name and phone number",Toast.LENGTH_LONG).show();

                } else {
                    if (saveContact.getText().toString().equalsIgnoreCase("Update")) {
                        updateContact();

                    } else {

                        saveContact();
                    }
                }
            }
        });

        addContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linearLayout.setVisibility(View.VISIBLE);
                saveContact.setText("Save");
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        loadAdapter();
    }
    /**
     * This method use to update the contact details
     * */
    private void updateContact()
    {
    Contact contact=new Contact();
    contact.setName(name.getText().toString());
    contact.setPhoneNumber(phone.getText().toString());
    contact.setID(primaryId);
    db.updateContact(contact);
    loadAdapter();
    Toast.makeText(MainActivity.this, "Data has been updated successfully",Toast.LENGTH_LONG).show();
    linearLayout.setVisibility(View.GONE);
    name.setText("");
    phone.setText("");
    primaryId=0;
}
    /**
     * This method use to save the contact details
     */
    private void saveContact()
  {
      String status=db.addContact(new Contact(name.getText().toString(),phone.getText().toString()));

      if (status.equalsIgnoreCase("Success"))
      {
          Toast.makeText(MainActivity.this, "Data has been saved successfully",Toast.LENGTH_LONG).show();
          loadAdapter();
          name.setText("");
          phone.setText("");
          linearLayout.setVisibility(View.GONE);

      }
  }
    /**
     * This method is used to get all the records from database and load into adapter
     */
    public void loadAdapter()
    {
        List<Contact> contacts = db.getAllContacts();
        contactAdapter=new ContactAdapter(MainActivity.this,contacts);
        listView.setAdapter(contactAdapter);
        contactAdapter.notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    /**
     * This method is used to get value from adapter to edit contact details
     */
    public void editContact(String mName,String mPhone,int id)
    {
        name.setText(mName);
        phone.setText(mPhone);
        saveContact.setText("Update");
        primaryId=id;
        linearLayout.setVisibility(View.VISIBLE);
    }
}
